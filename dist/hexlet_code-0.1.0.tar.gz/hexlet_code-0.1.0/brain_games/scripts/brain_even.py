#!/usr/bin/env python
from brain_games.core import game_logic
from brain_games.games import even


def main():
    game_logic(even)


if __name__ == '__main__':
    main()
