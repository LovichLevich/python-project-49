### Hexlet tests and linter status:
[![Actions Status](https://github.com/LovichLevich/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/LovichLevich/python-project-49/actions)
[![Maintainability]("https://api.codeclimate.com/v1/badges/53a8a6e68b29c607662d/maintainability"]"https://codeclimate.com/github/LovichLevich/python-project-49/maintainability")